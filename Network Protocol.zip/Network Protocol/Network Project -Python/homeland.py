
import socket
import sys
import struct
import time


#####################################
# The function cut_data receive string data
# and cutting it into pieces of 497
# return : list of all the sub string
# (the string after cut)
#####################################
def cut_data(data):
    dic_data = {}
    length = len(data)
    num_of_packt = length / 497
    remain = length % 497
    start = 0
    end = 497
    for i in xrange(0, num_of_packt):
        s=data[start:end]
        st=create_packet_to_send(s, i)
        dic_data[i] = st
        start = start + 497
        end = end + 497
    if (remain > 0 and length > 497):
        ss=data[start:]
        st = create_packet_to_send(ss, i+1)
        dic_data[i + 1] = st
    elif (remain > 0 and length < 497):
        s1=data[start:]
        st = create_packet_to_send(s1, i + 1)
        dic_data[0] = st

    return dic_data


###########################################
# The function calc_checksum receive packet
# to calculate check sum on it and return
# the check sum integer
###########################################
def calc_checksum(packet):
    total = 0

    # Add up 16-bit words
    num_words = len(packet) // 2
    for chunk in struct.unpack("!%sH" % num_words, packet[0:num_words * 2]):
        total += chunk

    # Add any left over byte
    if len(packet) % 2:
        total += ord(packet[-1]) << 8

    # Fold 32-bits into 16-bits
    total = (total >> 16) + (total & 0xffff)
    total += total >> 16
    return (~total + 0x10000 & 0xffff)


#############################################
# the function send_finish create the "finish"
# packet.
# return pointer to the packet
#############################################
def send_finish():
    frm_struct_str = "{}s".format(len("finish"))  # get the formate of the data ( the data length in the packet)
    struct_para = '!H' + 'c' + frm_struct_str  # construct the struct formate frm
    string = str(1) + "finish"
    checkSum = calc_checksum(string)
    st = struct.pack(struct_para, checkSum, chr(1),
                     "finish")  # send the embassy to that I finish to send packets,send 'F' for finish
    return st


###################################################
# the function check_pack receive the chech sum
# of the packet,the serial number of the packet
# and the data of the packet
# the function calculate the checksum of the packet
# and retrun it
###################################################
def check_pack(check_sum_of_the_sender, serial_num, pack_data):
    serial_and_data_checksum = str(serial_num) + pack_data
    rec_check = calc_checksum(serial_and_data_checksum)
    return rec_check


###################################################
# this function receive the data and the serial number
# create the packet and return pointer to it
###################################################
def create_packet_to_send(data, serial_num):
    serial_and_data_checksum = str(serial_num) + data
    checkSum = calc_checksum(serial_and_data_checksum)
    string = data
    frm_struct_str = "{}s".format(len(string))  # get the formate of the data ( the data length in the packet)
    struct_para = '!H' + 'c' + frm_struct_str  # construct the struct formate frm
    st = struct.pack(struct_para, checkSum, chr(serial_num), string)  # the struct which we pass to the receiver
    return st


##################################################
# this function receive check sum ,string data
# and check if the packet data was changed
# return True if it wasnt change elae otherwise
##################################################
def checksum_valid(checksum, string):
    rec_check = calc_checksum(string)
    if (rec_check == checksum):
        return True
    else:
        return False


###########################################
# this function send again all the packets
# the Embassy won't get
###########################################
def send_all_dic_pack(dict):
    for k in dict.keys():
        s = dict[k]
        sock.sendto(s, (UDP_IP, UDP_PORT))


##################################################
# this function get the bytes of the ack and create
# binary string of it
##################################################
def get_the_string_of_ackes(length, unpacked_data):
    out_str = ""
    last_index = (length - 3) + 1
    for m in xrange(0, last_index):
        r = ('{0:08b}'.format(unpacked_data[m + 2]))
        rev = r[::-1]
        out_str = out_str + rev

    return out_str


# the program begin fron here:

UDP_IP = sys.argv[1]

UDP_PORT = 10000

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # UDP connetion
print "hi"
sock.sendto("Hello", (UDP_IP, UDP_PORT))  # send to the relay hello for first connetion
data, addr = sock.recvfrom(7)  # how many byte to read from socket for the hello of the relay
file_input = open("input.txt", 'r')  # read from input file
s = file_input.read()

if file_input.read() == "":  # if I finish to read from the input file
    file_input.close()

dict = cut_data(s)  # dictionary of the serial number of the data (key) data of the packet (value)
# send all the packets
for k in dict.keys():
    s = dict[k]
    sock.sendto(s, (UDP_IP, UDP_PORT))

sock.settimeout(0.2)  # timeout

while True:
    while (len(dict) != 0):  # while there is packets which the embassy won't get yet
        try:
            data, addr = sock.recvfrom(1024)

            unpacked_data = struct.unpack("!Hc" + str(len(data) - 3) + "B", data)

            str_ack = get_the_string_of_ackes(len(unpacked_data), unpacked_data)

            if (checksum_valid(unpacked_data[0], str_ack)):
                if (ord(unpacked_data[1]) == 1):

                    for k in dict.keys():
                        if (dict.has_key(k)):
                            if (str_ack[k] == '1' ):
                                del dict[k]#print "I receive ack for packet number:",
                            else:
                                s = dict[k]
                                sock.sendto(s, (UDP_IP, UDP_PORT))

        except socket.timeout:  # after the time out finish
            send_all_dic_pack(dict)

    # finish to send all packets part
    if (len(dict) == 0):  # if there is not more packets to send
        try:

            st = send_finish()  # send the embassy to that I finish to send packets,send 'F' for finish
            sock.sendto(st, (UDP_IP, UDP_PORT))
            data, addr = sock.recvfrom(1024)  # wait for 'F' from the embassy
            unpacked_data = struct.unpack("!Hc" + str(len(data) - 3) + "B", data)

            str_ack = get_the_string_of_ackes(len(unpacked_data), unpacked_data)

            if (checksum_valid(unpacked_data[0], str_ack)):

                if (ord(unpacked_data[1]) == 0):
                    sock.close()
                    break
        except socket.timeout:
            st = send_finish()  # send the embassy to that I finish to send packets,send 'F' for finish
            sock.sendto(st, (UDP_IP, UDP_PORT))



