

import socket
import struct
import sys
import time


################################################
# this function cut the list of the packets
# we receive to sub list of 8 charecters (Byte)
################################################
def cut(string):
    list = []
    length = len(string)
    start = 0
    end = 8

    while end <= length:
        byte = string[start:end]
        list.append(byte)  # list[i]= number of 8 bits that represent the packet we receive
        start = start + 8
        end = end + 8

    return list


##############################################
# convert the byte of the 8 charecters to the
# number which its represent
# return the number which represent the byte
##############################################
def convert_list_to_bits(str):
    a = 0
    for i in range(len(str) - 1, -1, -1):
        if (str[i] == '1'):
            mask = 1
            mask = mask << i
            a = a + mask
    return a


###################################################
# this function create a list of all the
# numbers which represent all the bytes we create
# in the function cut
# return list of all the numbers represent the bytes
###################################################
def func_of_num_to_represent_the_bytes(ls):
    l = []
    for i in xrange(0, len(ls)):
        n = convert_list_to_bits(ls[i])
        l.append(n)
    return l


###################################################
# this function create the ack packet and return
# pointer to it
###################################################
def send_Ack(ack_str, is_finish):
    string = ''.join(ack_str)
    check_s = calc_checksum(string)
    ls_str_bytes = cut(string)  # I receive list of strings.in each cell there is string of length 8 (byte)
    NumElements = len(ls_str_bytes)  # get the formate of the data ( the data length in the packet)
    l = func_of_num_to_represent_the_bytes(ls_str_bytes)  # I want to send the l list
    frm_struct_str = 'B' * NumElements  # get the formate of the data ( the data length in the packet)
    struct_para = '!H' + 'c' + frm_struct_str
    st = struct.pack(struct_para, check_s, chr(is_finish), *l)
    return st


################################################################
# this function receive the list of the ack we get so far
# and the serial number of the new packet we receive and update
# the ack list .
# return the update list
################################################################
def update_Ack_str(acom_ack_for_packet, serial_number):
    if (acom_ack_for_packet[serial_number] != '1'):
        acom_ack_for_packet[serial_number] = '1'
    return acom_ack_for_packet


#################################################
# this function send the finish packet which means
# we finish to write the data into the file
#################################################
def send_finish():
    st = struct.pack("!cc", chr(1), chr(70))
    return st


#################################################
#
#
#################################################
def calc_checksum(packet):
    total = 0

    # Add up 16-bit words
    num_words = len(packet) // 2
    for chunk in struct.unpack("!%sH" % num_words, packet[0:num_words * 2]):
        total += chunk

    # Add any left over byte
    if len(packet) % 2:
        total += ord(packet[-1]) << 8

    # Fold 32-bits into 16-bits
    total = (total >> 16) + (total & 0xffff)
    total += total >> 16
    return (~total + 0x10000 & 0xffff)


##############################################
# this function check if the packet is not distrupted
# using the check sum calculation function
# return the calcuated check sum
################################################
def check_pack(check_sum_of_the_sender, serial_num, pack_data):
    serial_and_data_checksum = str(serial_num) + pack_data
    rec_check = calc_checksum(serial_and_data_checksum)
    return rec_check


############################################
# this function send write the data we recive
# the output file
############################################
def write_to_file(fileW, dict):
    for key in dict:
        fileW.write(dict[key])


##################################################
# this function initialize the ack list
# n is the number of cells in the list,in our case
# 208 cell because there can be al most 208 packet
# we can receive
##################################################
def zerolistmaker(n):
    listofzeros = ['0'] * n
    return listofzeros


# the program start from here:
UDP_IP = sys.argv[1]

UDP_PORT = 10000

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # UDP
dict = {}

sock.sendto("hi", (UDP_IP, UDP_PORT))

data, addr = sock.recvfrom(1024)  # receive the hello from relay
fileW = open("output.txt", 'w')

flag = False  # flag to know if we recive the finish packet more then once

acom_ack_for_packet = zerolistmaker(208)
sock.settimeout(3)
while True:
    try:

        data, addr = sock.recvfrom(1024)  # buffer size is 1024 bytes
        unpacked_data = struct.unpack("!Hc" + str(len(data) - 3) + "s", data)  # unpacket the packet from the homeland
        check_sum = check_pack(unpacked_data[0], ord(unpacked_data[1]), unpacked_data[2])
        if (check_sum == unpacked_data[0]):  # check if the checksum is valid
            if (unpacked_data[2] != "finish"):
                k = ord(unpacked_data[1])  # take the packet's number
                if (dict.has_key(k) == False):  # if i haven't receive the current pucket yet
                    # update the string ack that i receive the k'th packet
                    acom_ack_for_packet = update_Ack_str(acom_ack_for_packet, k)
                    st = send_Ack(acom_ack_for_packet, 1)
                    sock.sendto(st, (UDP_IP, UDP_PORT))  # send to the homeland ack
                    dict[k] = unpacked_data[2]  # add the data to the list
                else:
                    st = send_Ack(acom_ack_for_packet, 1)  # send to the homeland the accomulate ack again
                    sock.sendto(st, (UDP_IP, UDP_PORT))  # send to the homeland ack
            else:
                if (flag == False):
                    print "i gonna to write to file"
                    write_to_file(fileW, dict)
                    fileW.close()
                    print "i finish to write to file"
                    flag = True

                t = send_Ack(acom_ack_for_packet, 0)
                sock.sendto(t, (UDP_IP, UDP_PORT))

    except socket.timeout:
        st = send_Ack(acom_ack_for_packet, 1)  # send ack that I receive this packet
        sock.sendto(st, (UDP_IP, UDP_PORT))  # send to the homeland ack



